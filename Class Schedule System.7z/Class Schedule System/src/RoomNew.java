public class RoomNew {
    String RoomNo;
    String[] RoomTimings = {"8AM-11AM", "11AM-1PM", "1PM-4PM", "4PM-7PM"};

    public String getRoomNo() {
        return RoomNo;
    }

    public String[] getRoomTimings() {
        return RoomTimings;
    }

}